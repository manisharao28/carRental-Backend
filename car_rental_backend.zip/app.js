const express = require('express')
const app = express()
const cors = require('cors')
require('dotenv').config()
const { getConnection } =require('./connection')
const { loginHandler } = require('./handler')
const cookieParser = require('cookie-parser')
const { cookieWithJwt } = require('./middleware')
const PORT=4000;
const bodyParser = require('body-parser')
const cookieSession=require('cookie-session');
const indexRouter = require('./gitAuth');
const jwt = require('jsonwebtoken');

const secretKey = 'asjdgfjhdgjkadgkdgjdf';

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())

app.use(cors({
    origin:'*'
}))
app.get('/', function (req, res) {
  res.send('Hello World')
})
app.use(cookieSession({
    name:'sess', //name of the cookie in the browser
    secret:'asdfgh',
    httpOnly:true,
    secure: true 
    }))
app.use(cookieParser())

app.use('/oauth', indexRouter);
app.post('/login', async function(req, res) {
     const { name , password }= req.body;                      
      if(name && password){

        const getConn = await getConnection();  
        const result = await getConn.query(`select Login_Name as foundId from Login_Details where Login_Name='${name}' and Login_password='${password}'`)    
    
        const user = result.recordsets[0][0];

       const jwtToken=  jwt.sign(user, secretKey, { expiresIn: '1h' });

        res.cookie('token', jwtToken, { maxAge: 900000, httpOnly: true , Path:'/'});
        res.status(200).send({ user, token: jwtToken});

      }else{
        res.status(500).json({error:'ot email and password'});
      }
  

  })

app.post('/tripbook', async function (req, res) {
    const { fname,lname,email,pickupaddr,dropoffaddr,tripdate, carId }= req.body;
    const getConn = await getConnection();  
    const result = await getConn.query(`
    INSERT INTO Booking_Details(Bkng_FName,Bkng_LName,Bkng_Email,Bkng_PkupAddr,Bkng_DroffAddr,Bkng_TripDate,Bkng_carLstId) 
    VALUES('${fname}','${lname}','${email}','${pickupaddr}','${dropoffaddr}','${tripdate}',${carId})
    `)        
    res.send({Booking:true})   
})
app.post('/contactDet', async function (req, res) {
    const { name,email,desc }= req.body;
    const getConn = await getConnection();  
    const result = await getConn.query(`
    INSERT INTO Contact_details(CntDet_Name,CntDet_email,CntDet_desc)VALUES('${name}','${email}','${desc}')
    `)        
    res.send({Contact:true})   
})

app.get('/carlist', async function (req, res) { 
    quer=pagination({"pageStart":0,"pageEnd":10})   
    const getConn = await getConnection();  
    const result = await getConn.query(quer)        
    res.send(result.recordsets[0])   
})

app.get('/carCategory', async function (req, res) {   
    const getConn = await getConnection();  
    const result = await getConn.query(`
    SELECT * FROM car_Category
    `)        
    res.send(result.recordsets[0])   
})

app.get('/carType', async function (req, res) {
    const getConn = await getConnection();  
    const result = await getConn.query(`
    SELECT * FROM car_Type
    `)        
    res.send(result.recordsets[0])   
})

app.post('/carFilter', async function (req, res) {
    quer=filter(req.body)
    const getConn = await getConnection();  
    const result = await getConn.query(quer)        
    res.send(result.recordsets[0])   
})

app.post('/sortPrice', async function (req, res) {
    quer=sort(req.body)
    const getConn = await getConnection();  
    const result = await getConn.query(quer)        
    res.send(result.recordsets[0])   
})

app.post('/page', async function (req, res) {   
    quer=pagination(req.body) 
    const getConn = await getConnection();  
    const result = await getConn.query(quer)        
    res.send(result.recordsets[0])   
})

function pagination(req){
    const {pageStart,pageEnd}=req    
    qry=`SELECT CrMod_Id,CrMod_Name,CrMod_img,CrTyp_Name,Crgry_Name,CrMod_price,crt.CrTyp_Id,crt.Crgry_Id FROM car_Model as crt
    LEFT JOIN car_Category as ctr ON  ctr.Crgry_Id=crt.Crgry_Id
    LEFT JOIN car_Type as cty ON cty.CrTyp_Id=crt.CrTyp_Id
    WHERE CrMod_Id>=${parseInt(pageStart)} and CrMod_Id<=${parseInt(pageEnd)}`
    return qry
}

function sort(req){
    const {hightoLow}=req
    var condn=(hightoLow)?"DESC":"ASC";
    qry=`SELECT CrMod_Name,CrMod_img,CrTyp_Name,Crgry_Name,CrMod_price,crt.CrTyp_Id,crt.Crgry_Id,CrMod_Id FROM car_Model as crt
    LEFT JOIN car_Category as ctr ON  ctr.Crgry_Id=crt.Crgry_Id
    LEFT JOIN car_Type as cty ON cty.CrTyp_Id=crt.CrTyp_Id
    ORDER BY CrMod_price ${condn}`
    return qry

}
function filter(req) {
    const {categoryId, cartypeId}=req    
    condn=""
    condn=(categoryId != 0)?condn+"crt.Crgry_Id="+categoryId:"";    
    condn=(categoryId != 0 && cartypeId != 0)?condn+" and ":condn;   
    condn=(cartypeId != 0)?condn+"crt.CrTyp_Id="+cartypeId:condn;    
    qry=`SELECT CrMod_Name,CrMod_img,CrTyp_Name,Crgry_Name,CrMod_price,crt.CrTyp_Id,crt.Crgry_Id,CrMod_Id FROM car_Model as crt
    LEFT JOIN car_Category as ctr ON  ctr.Crgry_Id=crt.Crgry_Id
    LEFT JOIN car_Type as cty ON cty.CrTyp_Id=crt.CrTyp_Id
    where ${condn}`    
    return qry
  }


app.post('/register', async function (req, res) {
    const { name ,email, password }= req.body;
    const getConn = await getConnection();  
    const result = await getConn.query(`
    IF EXISTS (select * from Login_Details where Login_Name='${name}' and Login_password='${password}')
        BEGIN    
            Update Login_Details
            SET Login_Name='${name}',Login_Email='${email}',Login_password='${password}'
            WHERE Login_Id=(select Login_Id from Login_Details where Login_Name='${name}' and Login_password='${password}')
        END
    ELSE
        BEGIN   
            Insert into Login_Details(Login_Name,Login_Email,Login_password) values('${name}','${email}','${password}')
        END    
    `)  
    res.send({register:true})         
})


app.listen(PORT,()=>{
    console.log("node is running"+PORT)
})