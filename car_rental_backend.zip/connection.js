const sql = require('mssql')
const sqlConfig = {
  user: 'DB_GROUP_09',
  password: 'DB_GROUP_09',
  database: 'DB_GROUP_09',
  server:  '141.215.69.65',
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  },
  options: {
    encrypt: true, // for azure
    trustServerCertificate: true // change to true for local dev / self-signed certs
  }
}


async function getConnection(){
  try {
   // make sure that any items are correctly URL encoded in the connection string
   let pool = await new sql.ConnectionPool (sqlConfig)
   let connect = await pool.connect();
    let request = await connect.request();
   await sql.connect(sqlConfig)
   return sql
  } catch (err) {
   // ... error checks
  } 
 }

 module.exports={
  getConnection 
 }